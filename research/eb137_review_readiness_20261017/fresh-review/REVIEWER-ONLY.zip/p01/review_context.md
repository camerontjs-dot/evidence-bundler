# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p01`

Claim:

Fictional Procedure Sable-17 revision 4 became effective on 3 March 2031.

### Passage `passage:0422ce28897c2733e3723d3f7175478a`

- Source: `src-p01-sable-record`
- Offsets: 37:474
- Admission: `needs-review`

Passage text:

```
Training example only. All names, identifiers and dates in this record are invented.

Document: Procedure Sable-17
Revision: 4
Approval date: 1 March 2031
Effective date: 3 March 2031
Status: current in this fictional register.

The approval date records when the quality lead signed revision 4. The effective date records when that revision became the working procedure. Revision 3 ceased to be current when revision 4 became effective.
```

Display context (not admitted text):

```
# Fictional Sable document register
```
