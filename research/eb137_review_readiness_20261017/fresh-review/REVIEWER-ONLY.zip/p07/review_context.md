# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p07`

Claim:

For the fictional Ilex-9 solvent check, the acceptance ceiling is 0.08 mg/L.

### Passage `passage:30c70607c2a17efa80e5359a93928099`

- Source: `src-p07-archive-7q`
- Offsets: 0:305
- Admission: `needs-review`

Passage text:

```
Fictional archive note 7Q: Ilex-9 check

This is an invented laboratory-record layout used for a software exercise.

Archive note 7Q concerns the Ilex-9 solvent check. Its acceptance-ceiling field is expressed in mg/L. The recorded ceiling value appears in the decision table at the end of this same note.
```

### Passage `passage:6adcbccf2a04d9c75689ed2f09c7af0a`

- Source: `src-p07-archive-7q`
- Offsets: 6484:6706
- Admission: `needs-review`

Passage text:

```
Decision table for archive note 7Q

Acceptance ceiling: 0.08.
The subject key and measurement unit for this field are defined in the opening header of archive note 7Q. The intermediate entries record custody handling only.
```

### Passage `passage:01417dd7eefe43b980adc51ab74a4533`

- Source: `src-p07-archive-7q`
- Offsets: 307:2066
- Admission: `needs-review`

Passage text:

```
Chain-of-record entries follow.
Entry 01: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 02: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 03: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 04: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 05: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 06: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 07: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 08: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
Entry 09: the archive clerk logged an envelope transfer, checked the page count against the register, and recorded the shelf position. This administrative entry contains no analytical result.
```
