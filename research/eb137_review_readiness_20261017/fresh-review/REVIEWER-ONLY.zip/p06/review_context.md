# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p06-1`

Claim:

Fictional Study Halcyon-2 requires a signed sampling log.

### Passage `passage:836fbe641896a4af00cb4226e5061c3f`

- Source: `src-p06-halcyon-log`
- Offsets: 0:465
- Admission: `needs-review`

Passage text:

```
Fictional Study Halcyon-2: sampling-log requirement

This is an invented research-administration excerpt.

The Halcyon-2 protocol requires the sampling log to be signed by the collector after each sampling session. The signature binds the collector to the session identifier and collection date. The blank log template has a required signature field.

The excerpt describes sampling-log completion. No archive-retention schedule is included in this supplied source.
```

## Target `clm-p06-2`

Claim:

Fictional Study Halcyon-2 records a planned 24-month archive retention period.

### Passage `passage:836fbe641896a4af00cb4226e5061c3f`

- Source: `src-p06-halcyon-log`
- Offsets: 0:465
- Admission: `needs-review`

Passage text:

```
Fictional Study Halcyon-2: sampling-log requirement

This is an invented research-administration excerpt.

The Halcyon-2 protocol requires the sampling log to be signed by the collector after each sampling session. The signature binds the collector to the session identifier and collection date. The blank log template has a required signature field.

The excerpt describes sampling-log completion. No archive-retention schedule is included in this supplied source.
```
