# Reviewer rule

For each retained proposition/passage pair, choose `accepted`, `rejected` or `needs-review`, with a nonblank reason.

**Accept only when the admitted passage text itself is materially on-target and locally adequate for subsequent assessment.** Display context may orient the reviewer to the source, but it is explicitly not admitted downstream and therefore may not supply a fact, qualifier, subject, unit, scope or relation that is missing from the passage text. A passage can be accepted when it contradicts the claim; acceptance is evidence suitability, not support.

For a target with no retained passage, record the displayed gap state without inventing evidence.

Read p01 through p08 in that order. Permitted inputs are this rule and each corresponding review_context.md and review_record.json only. No prior conversation, implementation, tests, oracle, old decisions, raw sources or external lookup is permitted.
Change only decision and reason values in the generated review records. Preserve each first decision. Return a separate receipt with actual actor identity/model, input files opened, start/end and elapsed effort per target, actions, gap notes, external lookups (including zero), and any prior exposure or contamination. Do not claim human identity or human throughput for an agent. Stop on prohibited exposure and preserve the receipt. The execution custodian must supply the actual launch, identity and access evidence; self-description alone does not establish independence.
