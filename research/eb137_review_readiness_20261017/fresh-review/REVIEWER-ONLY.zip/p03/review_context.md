# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p03-1`

Claim:

Fictional Procedure Wren-4 requires two different reviewers before document release.

### Passage `passage:c310360a9e1800af86c01fd2cc9a461c`

- Source: `src-p03-wren-review`
- Offsets: 43:467
- Admission: `needs-review`

Passage text:

```
This invented training procedure applies to document release in the Wren-4 workflow.

Before document release under Procedure Wren-4, two different reviewers must complete their reviews. One person may not occupy both reviewer positions for the same release. The release checklist records both reviewer names.

This section describes the required review arrangement; it does not record whether a particular release complied.
```

Display context (not admitted text):

```
# Fictional Procedure Wren-4: review rule
```

### Passage `passage:db558da33b045594e1b564285d081a54`

- Source: `src-p03-wren-reconcile`
- Offsets: 51:482
- Admission: `needs-review`

Passage text:

```
This invented training procedure applies to document release in the Wren-4 workflow.

Before document release under Procedure Wren-4, a reconciliation record must be completed. It records how review comments were resolved and identifies the final document revision. A release with no reconciliation record remains incomplete under this procedure.

This section describes the required record; it does not certify any actual release.
```

Display context (not admitted text):

```
# Fictional Procedure Wren-4: reconciliation rule
```

## Target `clm-p03-2`

Claim:

Fictional Procedure Wren-4 requires a reconciliation record before document release.

### Passage `passage:db558da33b045594e1b564285d081a54`

- Source: `src-p03-wren-reconcile`
- Offsets: 51:482
- Admission: `needs-review`

Passage text:

```
This invented training procedure applies to document release in the Wren-4 workflow.

Before document release under Procedure Wren-4, a reconciliation record must be completed. It records how review comments were resolved and identifies the final document revision. A release with no reconciliation record remains incomplete under this procedure.

This section describes the required record; it does not certify any actual release.
```

Display context (not admitted text):

```
# Fictional Procedure Wren-4: reconciliation rule
```

### Passage `passage:c310360a9e1800af86c01fd2cc9a461c`

- Source: `src-p03-wren-review`
- Offsets: 43:467
- Admission: `needs-review`

Passage text:

```
This invented training procedure applies to document release in the Wren-4 workflow.

Before document release under Procedure Wren-4, two different reviewers must complete their reviews. One person may not occupy both reviewer positions for the same release. The release checklist records both reviewer names.

This section describes the required review arrangement; it does not record whether a particular release complied.
```

Display context (not admitted text):

```
# Fictional Procedure Wren-4: review rule
```
