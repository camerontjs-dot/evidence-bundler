# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p05`

Claim:

For Juniper external lots, the hold-review window is 48 hours after receipt.

### Passage `passage:bfcaa9a2108d56a1c1c78f021bbf7620`

- Source: `src-p05-juniper-index`
- Offsets: 0:469
- Admission: `needs-review`

Passage text:

```
Fictional Juniper archive: surviving index fragment

This invented index card preserves search labels, not a procedure statement.

Labels: Juniper; external lots; hold review; 48; receipt.

The procedure body and the index column headings are absent. The fragment does not identify the unit attached to 48, does not connect receipt to a clock-start rule, and does not define the applicable lot population. A reader cannot reconstruct those relationships from this card.
```
