# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p02`

Claim:

The fictional Lumen pilot used archived samples from twelve sites.

### Passage `passage:2d032bfab20acc5b49eb331ad9db2153`

- Source: `src-p02-lumen-report`
- Offsets: 0:496
- Admission: `needs-review`

Passage text:

```
Fictional Lumen pilot: final sample-accountability note

This is an invented research record for a software exercise.

The final Lumen pilot report states that archived samples came from nine sites. Twelve sites were invited, but three provided no samples. These counts refer to contributing sites rather than individual samples. The pilot used only archived material and enrolled no new participants.

The invitation count and the contributing-site count are separate fields in the final record.
```
