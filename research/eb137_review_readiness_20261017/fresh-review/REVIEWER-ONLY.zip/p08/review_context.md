# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p08`

Claim:

Fictional Procedure Vale-6 requires an annual inventory review.

Gap: This target had no sources to search.
