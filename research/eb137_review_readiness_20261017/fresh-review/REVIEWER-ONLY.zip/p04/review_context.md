# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This file is the unreviewed run. Fill review_record.json and pass it with --review. The record binds the input file bytes and the unreviewed package hash.

## Target `clm-p04`

Claim:

Fictional Project Cedar uses a 48-hour deadline to triage a newly opened deviation.

### Passage `passage:b40c68f3b906c744d45ee38384f9fc86`

- Source: `src-p04-alder-triage`
- Offsets: 0:391
- Admission: `needs-review`

Passage text:

```
Fictional Project Alder: deviation-triage instruction

This invented instruction governs Project Alder only.

Project Alder uses a 48-hour deadline to triage a newly opened deviation. The deadline begins at the creation timestamp in Alder's deviation register. The triage owner records the initial classification and responsible team.

This source contains no policy for a different project.
```
