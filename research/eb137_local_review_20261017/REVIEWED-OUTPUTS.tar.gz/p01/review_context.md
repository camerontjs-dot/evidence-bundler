# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This run applied a review record bound to the input file bytes and the unreviewed package hash. Reasons stay in applied_review_record.json.

## Target `clm-p01`

Claim:

Fictional Procedure Sable-17 revision 4 became effective on 3 March 2031.

### Passage `passage:0422ce28897c2733e3723d3f7175478a`

- Source: `src-p01-sable-record`
- Offsets: 37:474
- Admission: `accepted`

Passage text:

```
Training example only. All names, identifiers and dates in this record are invented.

Document: Procedure Sable-17
Revision: 4
Approval date: 1 March 2031
Effective date: 3 March 2031
Status: current in this fictional register.

The approval date records when the quality lead signed revision 4. The effective date records when that revision became the working procedure. Revision 3 ceased to be current when revision 4 became effective.
```

Display context (not admitted text):

```
# Fictional Sable document register
```
