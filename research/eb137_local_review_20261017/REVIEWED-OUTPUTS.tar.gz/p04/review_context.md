# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This run applied a review record bound to the input file bytes and the unreviewed package hash. Reasons stay in applied_review_record.json.

## Target `clm-p04`

Claim:

Fictional Project Cedar uses a 48-hour deadline to triage a newly opened deviation.

Gap: Retained passages were reviewed and none were accepted.

### Passage `passage:b40c68f3b906c744d45ee38384f9fc86`

- Source: `src-p04-alder-triage`
- Offsets: 0:391
- Admission: `rejected`

Passage text:

```
Fictional Project Alder: deviation-triage instruction

This invented instruction governs Project Alder only.

Project Alder uses a 48-hour deadline to triage a newly opened deviation. The deadline begins at the creation timestamp in Alder's deviation register. The triage owner records the initial classification and responsible team.

This source contains no policy for a different project.
```
