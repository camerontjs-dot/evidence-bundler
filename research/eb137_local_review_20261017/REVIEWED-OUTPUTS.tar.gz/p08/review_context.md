# Review context

Display context is reconstructed for reading. It is not admitted text, and it does not change passage spans or identifiers.

This run applied a review record bound to the input file bytes and the unreviewed package hash. Reasons stay in applied_review_record.json.

## Target `clm-p08`

Claim:

Fictional Procedure Vale-6 requires an annual inventory review.

Gap: This target had no sources to search.
